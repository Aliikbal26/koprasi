<div class="main-sidebar sidebar-style-2">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="/dashboard">Sindang Berkah</a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="index.html">Kop</a>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-header">Dashboard</li>
            <li class="<?php echo e(request()->is('dashboard') ? 'active' : ''); ?>"><a href="<?php echo e(route('dashboard')); ?>" class="nav-link"><i class="fas fa-weight"></i><span>Dashboard</span></a></li>
            <li class="menu-header">Produk</li>
            <li class="nav-item dropdown <?php echo e(request()->is(['products*', 'products-out*']) ? 'active' : ''); ?>">
                <a href="#" class="nav-link has-dropdown"><i class="fas fa-boxes"></i><span>Produk</span></a>
                <ul class="dropdown-menu">
                    <li class="<?php echo e(request()->is('products*') ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(route('products.index')); ?>"><i class="fas fa-arrow-alt-circle-right"></i><span>Produk Masuk</span></a></li>
                    <li class="<?php echo e(request()->is('products-out*') ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(route('checkout.index')); ?>"><i class="fas fa-arrow-alt-circle-left"></i><span>Produk Keluar</span></a></li>
                </ul>
            </li>
            <li class="nav-item dropdown <?php echo e(request()->is(['histori-masuk', 'histori-keluar']) ? 'active' : ''); ?>">
                <a href="#" class="nav-link has-dropdown"><i class="fas fa-history"></i><span>Histori</span></a>
                <ul class="dropdown-menu">
                    <li class="<?php echo e(request()->is('histori-masuk') ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(route('histori-masuk')); ?>"><i class="fas fa-arrow-alt-circle-right"></i> <span>Produk Masuk</span></a></li>
                    <li class="<?php echo e(request()->is('histori-keluar') ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(route('histori-keluar')); ?>"><i class="fas fa-arrow-alt-circle-left"></i> <span>Produk Keluar</span></a></li>
                </ul>
            </li>

            <li class="<?php echo e(request()->is('history') ? 'active' : ''); ?>"><a href="<?php echo e(route('report.index')); ?>" class="nav-link"><i class="fas fa-file"></i><span>Report Data</span></a></li>
            <li class="<?php echo e(request()->is('history') ? 'active' : ''); ?>"><a href="<?php echo e(route('profile.index')); ?>" class="nav-link"><i class="fas fa-user-alt"></i><span>Profile</span></a></li>

        </ul>
    </aside>
    
</div><?php /**PATH C:\xampp\htdocs\koprasi\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>