<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="section-header">
        <h1>Histori Produk</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('histori-masuk')); ?>">Histori</a></div>
        </div>
    </div>

    
    <div class="section-body">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Histori Produk Masuk</h4>
                    </div>

                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-1" id="table-1">
                                <thead>
                                    <tr>
                                        <th class="text-center">
                                            No
                                        </th>
                                        <th>Nama Produk</th>
                                        <th>Stok Masuk</th>
                                        <th>Tanggal</th>
                                        <th>Photo</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($products->count() == 0): ?>
                                    <tr>
                                        <td colspan="6" class="text-center">Belum ada produk masuk...</td>
                                    </tr>
                                    <?php else: ?>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="align-middle"><?php echo e($loop->iteration); ?></td>
                                        <td class="align-middle"><?php echo e($row->product->name); ?></td>
                                        <td class="align-middle"><?php echo e($row->count); ?></td>
                                        <td class="align-middle"><?php echo e($row->created_at); ?></td>
                                        <td class="align-middle">
                                            <?php if($row->product->photo == null): ?>
                                            <img alt="image" src="<?php echo e(asset('file_upload/produk/produk.png')); ?>" class="rounded-circle" width="30" data-toggle="tooltip" title="Produk">
                                            <?php else: ?>
                                            <img alt="image" src="<?php echo e(asset('file_upload/produk/' . $row->product->photo)); ?>" class="" width="30" data-toggle="tooltip" title="Produk">
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\koprasi\resources\views/histori/input.blade.php ENDPATH**/ ?>