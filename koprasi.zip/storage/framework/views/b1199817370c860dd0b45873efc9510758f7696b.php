<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="section-header">
        <h1>Produk</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('products.index')); ?>">Produk</a></div>
            <div class="breadcrumb-item"><?php echo e($product->name); ?></div>
        </div>
    </div>

    
    <div class="section-body">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4><?php echo e($product->name); ?></h4>
                        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-secondary">kembali</a>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <?php if($product->photo == null): ?>
                                <img alt="image" src="<?php echo e(asset('file_upload/produk/produk.png')); ?>" class="img-fluid" width="100" title="Produk">
                                <?php else: ?>
                                <img alt="image" src="<?php echo e(asset('file_upload/produk/' . $product->photo)); ?>" class="img-fluid" witdh="100" title="Produk">
                                <?php endif; ?>
                                <!-- <img src="<?php echo e(asset('file_upload/produk/' . $product->photo)); ?>" alt="" class="img-fluid"> -->
                            </div>
                            <div class="col-md-5">
                                <table class="w-100">
                                    <tr>
                                        <td width="">Harga Beli</td>
                                        <td class="money text-primary"><?php echo e($product->first_price); ?></td>
                                    </tr>
                                    <tr>
                                        <td width="">Harga Jual</td>
                                        <td class="money text-primary"><?php echo e($product->last_price); ?></td>
                                    </tr>
                                    <tr>
                                        <td width="">Stok Barang</td>
                                        <td class="text-primary"><?php echo e($product->stok); ?></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\koprasi\resources\views/product/show.blade.php ENDPATH**/ ?>