<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="section-header">
        <h1>Profile</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></div>
            <div class="breadcrumb-item">Profile</div>
        </div>
    </div>

    
    <div class="section-body">
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h4>Profile</h4>
                        <a href="<?php echo e(route('profile.index')); ?>" class="btn btn-success edit-profile">Edit Profile</a>
                    </div>
                    <hr>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-4">
                                <!-- <?php if($user->foto == null): ?>
                                <img alt="image" src="<?php echo e(asset('assets/img/avatar/avatar-4.png')); ?>" class="rounded-circle" width="30" data-toggle="tooltip" title="Produk">
                                <?php else: ?>
                                <img alt="image" src="<?php echo e(asset('file_upload/produk/' . $user->foto)); ?>" class="" width="30" data-toggle="tooltip" title="Produk">
                                <?php endif; ?> -->
                                <img src="<?php echo e($user->foto == null ? 'assets/img/avatar/avatar-4.png' : 'file_upload/produk/' . $user->foto); ?>" class="img-thumbnail text-center" width="50%" alt="">
                            </div>
                            <div class="col-md-8 my-2">
                                <h6>Nama : <?php echo e($user->name); ?></h6>
                                <h6>Email : <?php echo e($user->email); ?></h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- modal edit profile -->
    <form action="<?php echo e(route('profile.update', $user->id)); ?>" method="post" class="modal-part modal-edit-profile" id="modal" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>

        <div class="form-group">
            <label for="name">Name<span class="text-danger">*</span></label>
            <input type="text" class="form-control " name="name" id="email" placeholder="Ali Ikbal" required>
        </div>
        <div class="form-group">
            <label for="email">Email<span class="text-danger">*</span></label>
            <input type="email" class="form-control " name="email" id="email" placeholder="example@gmail.com" required>
        </div>
        <div class="form-group">
            <label for="foto">Foto<span class="text-danger">*</span></label>
            <input type="file" class="form-control " name="foto" id="foto" placeholder="0" required>
        </div>
        <div class="d-flex justify-content-between align-items-center">
            <button type="submit" class="btn btn-primary">Edit</button>
        </div>
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\koprasi\resources\views/profile/profile.blade.php ENDPATH**/ ?>